#include<stdio.h>
static int z=20;
int main()
{
	printf("Hello\n");
}
