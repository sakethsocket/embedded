#include<stdio.h>
#include<unistd.h>
void main()
{
	/*int x;
	x=1/0;
	printf("%d\n",x);
	int *ptr;
	int i;
	//ptr=NULL;
	//printf("%d\n",*ptr);
	ptr=(int *)malloc(5*sizeof(int));
	for(i=0;i<10;i++)
		scanf("%d",&ptr[i]);
	for(i=0;i<10;i++)
		printf("%d\n",ptr[i]);*/
	int x;
	x=1;
	abort();
}
