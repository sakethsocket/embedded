#include<stdio.h>
void main()
{
/*	int x;
	printf("Enter\n");
	scanf("%d",&x);
	printf("%d",x);*/
	while(1)
		printf("Hi");
}
