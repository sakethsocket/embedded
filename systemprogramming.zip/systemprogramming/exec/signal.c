#include<stdio.h>
void main()
{
	int x=1;
	while(x>0)
	{
		printf("%d\n",x);
		x++;
	}
}
