#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/msg.h>
#include<string.h>
struct msg
{
    long msgtype;
    long pid;
    char buf[100];
};
struct msg message;
#define MSG_TYPE 1
#define KEY 0x1998860
int main()
{
    char buf[100]={0};
    int msqid;
    msqid=msgget(KEY,IPC_CREAT|0640);
    if(msqid<0)
    {
        printf("failed to create message queue id\n");
        exit(1);
    }
   // msgrcv(msqid,&message,sizeof(struct msg),MSG_TYPE,0);
    //printf("%d\n",message.msgtype);
    //printf("%d\n",message.pid);
    //printf("%s",message.buf);
     msgrcv(msqid,buf,sizeof(buf),MSG_TYPE,0);
     printf("%ld\n",((long int *)buf)[0]);
	printf("%ld\n",((long int *)buf)[1]);
	printf("%s\n",buf+(2*sizeof(long)));
    

}
